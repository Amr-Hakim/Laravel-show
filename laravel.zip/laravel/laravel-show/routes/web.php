<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/signup', function () {
    return view('signup');
});
//da lel page
Route::get('/edit_profile', function () {
    return view('edit_profile');
});

Route::get('/contactus', function () {
    return view('contactus');
});

Route::get('/items', function () {
    return view('items');
});

Route::get('/item_detail', function () {
    return view('item_detail');
});

Route::get('/setting', function () {
    return view('setting');
});

Route::get('/add_items', function () {
    return view('add_item');
});

Route::POST('signup/save','supplier_code@signup');

Route::get('setting', 'supplier_code@profile_data');
//da el action nafso
Route::get('edit_profile', 'supplier_code@get_profile_data_to_edit');



Route::POST('add_item/add', 'supplier_code@add_item');

Route::POST('edit_profile/update', 'supplier_code@edit_profile');

//login for supplier
Route::POST('login_supplier/login', 'supplier_code@login');

Route::get('/login_supplier', function () {
    return view('login_supplier');
});

Route::get('items', 'anony@all_items');

Route::POST('items/search', 'anony@get_items_search');

Route::POST('items/more', 'anony@get_item_detail');


