<?php $__env->startSection('supplier_content'); ?>

<!-- mn el web.php lamma tla2y get b el setting e3mlly el function profile_data elly f el supplier_code w h t return el all data elly f el setting w law > 0 e3mlly kol elly gy da -->


<?php if(count($all_data)>0): ?>
<?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div style='text-align:center;width:500px;margin-left:500px;margin-top:50px'>

<img src="<?php echo e(asset('storage/'.$supplier->supplier_photo)); ?>" width="200" height='200'/>
<h2><?php echo e($supplier->supplier_name); ?></h2>
<p><?php echo e($supplier->phone); ?></p>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('s_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/setting.blade.php ENDPATH**/ ?>