<?php $__env->startSection('content'); ?>
<div class='form-row' style='float:right;width:100%'>
<?php echo Form::open(['url' => 'items/search','files'=>true]); ?>

<div class='form-group col-md-10' style='float:left'>
<?php echo e(Form::text('t_word','',['class'=>'form-control','placeholder'=>'Search Here'])); ?>

</div>
<div class='form-group col-md-2' style='float:right'>
<?php echo e(Form::submit('Search',['class'=>'btn btn-primary'])); ?>

</div>
<?php echo Form::close(); ?>

</div>

<?php if(count($items)>0): ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width:300px;height:450px;float:left;margin:10px;padding:10px">
  <img src="<?php echo e(asset('storage/'.$item->item_photo)); ?>" class="card-img-top" alt="..." style='width:100%;height:60%'>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
    <p class="card-text" style='overflow:hidden;width:100%;height:70px'><?php echo e($item->short_desc); ?></p>



<?php echo Form::open(['url' => 'items/more','files'=>true]); ?>

<div class='form-row' style='display:none'>
<?php echo e(Form::text('t_id',$item->id,['class'=>'form-control','placeholder'=>'Search Here'])); ?>

</div>
<?php echo e(Form::submit('More',['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>




  </div>
</div>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/items.blade.php ENDPATH**/ ?>