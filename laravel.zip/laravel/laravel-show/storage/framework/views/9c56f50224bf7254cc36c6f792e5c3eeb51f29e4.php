<?php $__env->startSection('supplier_content'); ?>

<?php echo Form::open(['url' => 'add_item/add','files'=>true]); ?>


<div class='form-row' style='margin:50px;width:1000px'>
  <div class="form-group col-md-6">
  <?php echo e(Form::text('item_name','',['class'=>'form-control','placeholder'=>'Item Name'])); ?>

  </div>
  <div class="form-group col-md-6">
  <?php echo e(Form::text('item_price','',['class'=>'form-control','placeholder'=>'Item Price'])); ?>

  </div>
  <div class="form-group col-md-12">
  <?php echo e(Form::text('short_desc','',['class'=>'form-control','placeholder'=>'Short Description'])); ?>

  </div>
  <div class="form-group col-md-12">
  <?php echo e(Form::textarea('full_desc','',['class'=>'form-control','placeholder'=>'Full Description'])); ?>

  </div>
  <div class="form-group col-md-12">
  <?php echo e(Form::file('item_photo',['class'=>'form-control-file'])); ?>

  </div>
  <div class="form-group col-md-6">
  <?php echo e(Form::submit('Add Item',['class'=>'btn btn-outline-primary'])); ?>

  </div>

</div>

<?php echo Form::close(); ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('s_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/add_item.blade.php ENDPATH**/ ?>