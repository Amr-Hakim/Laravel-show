<?php $__env->startSection('content'); ?>
<h1>welcome to my site login</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/login.blade.php ENDPATH**/ ?>