<?php $__env->startSection('supplier_content'); ?>

<!-- mn el web.php lamma tla2y get b el edit profile e3mlly el function profile_data elly f el supplier_code w h t return el all data elly f el edit profile w law > 0 e3mlly kol elly gy da -->


<?php if(count($all_data)>0): ?>
<?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo Form::open(['url' => 'edit_profile/update','files'=>true]); ?>


<div class='form-row' style='margin:50px;width:1000px'>
  <div class="form-group col-md-6">
  <?php echo e(Form::text('supplier_name',$supplier->supplier_name,['class'=>'form-control'])); ?>

  </div>
  <div class="form-group col-md-6">
  <?php echo e(Form::text('phone',$supplier->phone,['class'=>'form-control'])); ?>

  </div>
  <div class="form-group col-md-12">
  <?php echo e(Form::password('pass',['class'=>'form-control','placeholder'=>'Password'])); ?>

  </div>
  <div class="form-group col-md-12">
  <?php echo e(Form::file('supplier_photo',['class'=>'form-control-file'])); ?>

  </div>
  <div class="form-group col-md-6">
  <?php echo e(Form::submit('Save Changes',['class'=>'btn btn-outline-success'])); ?>

  </div>

</div>

<?php echo Form::close(); ?>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('s_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/edit_profile.blade.php ENDPATH**/ ?>