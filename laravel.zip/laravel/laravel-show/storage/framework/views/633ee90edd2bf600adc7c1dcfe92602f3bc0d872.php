<?php $__env->startSection('content'); ?>
<h1>Signup now</h1>
<div style='width:300px;margin:50px'>
<?php echo Form::open(['url' => 'signup/save', 'files'=>true]); ?>

    <?php echo e(Form::text('t_name','',['class'=>'form-control','placeholder'=>'Your Name'])); ?>

    <?php echo e(Form::text('t_phone','',['class'=>'form-control','placeholder'=>'Your Phone'])); ?>

    <?php echo e(Form::email('t_email','',['class'=>'form-control','placeholder'=>'Your Email'])); ?>

    <?php echo e(Form::password('t_pass',['class'=>'form-control','placeholder'=>'****'])); ?>

    <?php echo e(Form::file('t_photo',['class'=>'form-control-file'])); ?>

    <?php echo e(Form::submit('Signup',['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/signup.blade.php ENDPATH**/ ?>