<?php $__env->startSection('content'); ?>

<?php echo Form::open(['url' => 'login_supplier/login','files'=>true]); ?>

<div class='form-row' style='margin:50px;width:800px;border:1px solid #ddd;border-radius:15px;padding:20px'>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <?php echo e(Form::email('t_email','',['class'=>'form-control'])); ?>

  </div>
<div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <?php echo e(Form::password('t_pass',['class'=>'form-control awesome'])); ?>

    
  </div>
  <div class="form-group form-check">
  <?php echo e(Form::submit('Login',['class'=>'btn btn-outline-primary'])); ?>

  </div>


  <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/login_supplier.blade.php ENDPATH**/ ?>