<?php $__env->startSection('content'); ?>

<?php if(count($data)>0): ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="space2"></div>
<section>
<div class="main_item_info">
    <div class="item_photo">
        <img src="<?php echo e(asset('storage/'.$item->item_photo)); ?>">
    </div>
<div class="item_data">
    <h2><?php echo e($item->item_name); ?></h2>
    <p><?php echo e($item->price); ?></p>
    <p>item category:Elctronics </p>
    <p>item unit: 5</p>
    <p>item size: 1028x500</p>
    <p>Transportation: Include</p>
    <button>Buy Now</button>
</div> 
</div>
<div class="space"></div>
<div class="full_desc">
    <h2>Full Description</h2>
    <p><?php echo e($item->full_desc); ?></p>
</div>

<div class="space"></div>


</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\laravel-show\resources\views/item_detail.blade.php ENDPATH**/ ?>