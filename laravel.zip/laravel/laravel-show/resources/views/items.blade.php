@extends('anony_layout.master')

@section('content')
<div class='form-row' style='float:right;width:100%'>
{!! Form::open(['url' => 'items/search','files'=>true]) !!}
<div class='form-group col-md-10' style='float:left'>
{{Form::text('t_word','',['class'=>'form-control','placeholder'=>'Search Here'])}}
</div>
<div class='form-group col-md-2' style='float:right'>
{{Form::submit('Search',['class'=>'btn btn-primary'])}}
</div>
{!! Form::close() !!}
</div>

@if(count($items)>0)
@foreach($items as $item)

<div class="card" style="width:300px;height:450px;float:left;margin:10px;padding:10px">
  <img src="{{asset('storage/'.$item->item_photo)}}" class="card-img-top" alt="..." style='width:100%;height:60%'>
  <div class="card-body">
    <h5 class="card-title">{{$item->item_name}}</h5>
    <p class="card-text" style='overflow:hidden;width:100%;height:70px'>{{$item->short_desc}}</p>



{!! Form::open(['url' => 'items/more','files'=>true]) !!}
<div class='form-row' style='display:none'>
{{Form::text('t_id',$item->id,['class'=>'form-control','placeholder'=>'Search Here'])}}
</div>
{{Form::submit('More',['class'=>'btn btn-primary'])}}
{!! Form::close() !!}



  </div>
</div>



@endforeach
@endif
@endsection