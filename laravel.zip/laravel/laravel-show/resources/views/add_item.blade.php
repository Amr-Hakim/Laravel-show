@extends('s_master.master')

@section('supplier_content')

{!! Form::open(['url' => 'add_item/add','files'=>true]) !!}

<div class='form-row' style='margin:50px;width:1000px'>
  <div class="form-group col-md-6">
  {{Form::text('item_name','',['class'=>'form-control','placeholder'=>'Item Name'])}}
  </div>
  <div class="form-group col-md-6">
  {{Form::text('item_price','',['class'=>'form-control','placeholder'=>'Item Price'])}}
  </div>
  <div class="form-group col-md-12">
  {{Form::text('short_desc','',['class'=>'form-control','placeholder'=>'Short Description'])}}
  </div>
  <div class="form-group col-md-12">
  {{Form::textarea('full_desc','',['class'=>'form-control','placeholder'=>'Full Description'])}}
  </div>
  <div class="form-group col-md-12">
  {{Form::file('item_photo',['class'=>'form-control-file'])}}
  </div>
  <div class="form-group col-md-6">
  {{Form::submit('Add Item',['class'=>'btn btn-outline-primary'])}}
  </div>

</div>

{!! Form::close() !!}

@endsection