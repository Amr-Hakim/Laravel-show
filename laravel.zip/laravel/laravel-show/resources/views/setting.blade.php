@extends('s_master.master')

@section('supplier_content')

<!-- mn el web.php lamma tla2y get b el setting e3mlly el function profile_data elly f el supplier_code w h t return el all data elly f el setting w law > 0 e3mlly kol elly gy da -->


@if(count($all_data)>0)
@foreach($all_data as $supplier)

<div style='text-align:center;width:500px;margin-left:500px;margin-top:50px'>

<img src="{{asset('storage/'.$supplier->supplier_photo)}}" width="200" height='200'/>
<h2>{{$supplier->supplier_name}}</h2>
<p>{{$supplier->phone}}</p>

</div>
@endforeach
@endif
@endsection