@extends('anony_layout.master')
@section('content')

{!! Form::open(['url' => 'login_supplier/login','files'=>true]) !!}
<div class='form-row' style='margin:50px;width:800px;border:1px solid #ddd;border-radius:15px;padding:20px'>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    {{Form::email('t_email','',['class'=>'form-control'])}}
  </div>
<div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    {{Form::password('t_pass',['class'=>'form-control awesome'])}}
    
  </div>
  <div class="form-group form-check">
  {{Form::submit('Login',['class'=>'btn btn-outline-primary'])}}
  </div>


  {!! Form::close() !!}

@endsection