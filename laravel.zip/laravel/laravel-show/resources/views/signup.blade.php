@extends('anony_layout.master')

@section('content')
<h1>Signup now</h1>
<div style='width:300px;margin:50px'>
{!! Form::open(['url' => 'signup/save', 'files'=>true]) !!}
    {{Form::text('t_name','',['class'=>'form-control','placeholder'=>'Your Name'])}}
    {{Form::text('t_phone','',['class'=>'form-control','placeholder'=>'Your Phone'])}}
    {{Form::email('t_email','',['class'=>'form-control','placeholder'=>'Your Email'])}}
    {{Form::password('t_pass',['class'=>'form-control','placeholder'=>'****'])}}
    {{Form::file('t_photo',['class'=>'form-control-file'])}}
    {{Form::submit('Signup',['class'=>'btn btn-primary'])}}
{!! Form::close() !!}
</div>
@endsection