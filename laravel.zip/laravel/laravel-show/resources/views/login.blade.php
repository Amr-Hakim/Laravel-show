
@extends('anony_layout.master')

@section('content')
<h1>welcome to my site login</h1>
@endsection