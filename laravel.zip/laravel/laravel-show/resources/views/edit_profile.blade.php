@extends('s_master.master')

@section('supplier_content')

<!-- mn el web.php lamma tla2y get b el edit profile e3mlly el function profile_data elly f el supplier_code w h t return el all data elly f el edit profile w law > 0 e3mlly kol elly gy da -->


@if(count($all_data)>0)
@foreach($all_data as $supplier)

{!! Form::open(['url' => 'edit_profile/update','files'=>true]) !!}

<div class='form-row' style='margin:50px;width:1000px'>
  <div class="form-group col-md-6">
  {{Form::text('supplier_name',$supplier->supplier_name,['class'=>'form-control'])}}
  </div>
  <div class="form-group col-md-6">
  {{Form::text('phone',$supplier->phone,['class'=>'form-control'])}}
  </div>
  <div class="form-group col-md-12">
  {{Form::password('pass',['class'=>'form-control','placeholder'=>'Password'])}}
  </div>
  <div class="form-group col-md-12">
  {{Form::file('supplier_photo',['class'=>'form-control-file'])}}
  </div>
  <div class="form-group col-md-6">
  {{Form::submit('Save Changes',['class'=>'btn btn-outline-success'])}}
  </div>

</div>

{!! Form::close() !!}


@endforeach
@endif
@endsection