<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\supplier;

//app > http > item

use App\item;
class supplier_code extends Controller
{
    public function signup(Request $req){
        $this->validate($req,[
            't_name'=>'required',
            't_pass'=>'required',
            't_email'=>'required',
            't_phone'=>'required'
            ]);

            $s = new Supplier;
            $s->supplier_name = $req->input('t_name');
            $s->password = $req->input('t_pass');
            $s->email = $req->input('t_email');
            $s->phone = $req->input('t_phone');
            $s->supplier_photo = $req->file('t_photo')->store('uploads','public');
            $s->save();
            $req->session()->put('s_email',$req->input('t_email'));
            return redirect('setting');
    }

      // 5od el data w 7ottaha l saf7et el setting bs
    public function profile_data(Request $req){

        $email_value=$req->session()->get('s_email');
        $all_data=supplier::where('email',$email_value)->get();

        // with de session l saf7a wa7da bs
        // view de zy header f el native
        return view('setting')->with('all_data',$all_data);

    }
    // add item method
    public function add_item(Request $req){
        $email_value=$req->session()->get('s_email');
        $item=new item;
        $item->item_name=$req->input('item_name');
        $item->price=$req->input('item_price');
        $item->supplier_email=$email_value;
        $item->item_photo=$req->file('item_photo')->store('item_img','public');
        $item->short_desc=$req->input('short_desc');
        $item->full_desc=$req->input('full_desc');
        $item->save();
        $all_data=supplier::where('email',$email_value)->get();
        return view('setting')->with('all_data',$all_data);
    }


    public function get_profile_data_to_edit(Request $req){
        $email_value=$req->session()->get('s_email');
        $all_data=supplier::where('email',$email_value)->get();
        // with de session l saf7a wa7da bs
        // view de zy header f el native
        return view('edit_profile')->with('all_data',$all_data);
    }

    public function edit_profile(Request $req){
        $email=$req->session()->get('s_email');
        $s=supplier::where('email',$email)->update([
            'supplier_name'=>$req->input('supplier_name'),
            'phone'=>$req->input('phone'),
            'supplier_photo'=>$req->file('supplier_photo')->store('uploads','public')
        ]);
        $all_data=supplier::where('email',$email)->get();
        return view('setting')->with('all_data',$all_data);
    }

    public function all_item(Request $req){
        $data=item::all();
        return view('items')->with('items',$data);
    }

    public function login(Request $req){
        //select by email and password
        $data=supplier::where([
            ['email', '=', $req->input('t_email')],
            ['password', '=', $req->input('t_pass')]
        ])->get();
        //then create session
        $req->session()->put('s_email',$req->input('t_email'));
        //then redirect to setting page
        return view('setting')->with('all_data',$data);
    }

    public function delete_item(Request $req){
        $email=$req->session()->get('s_email');
        $item_id=$req->input('t_id');
        $up=item::where('id', $item_id)->delete();
        //after updating data go to setting page with new values
        $so=item::where('email',$email)->get();
        return view('my_items')->with('all_data',$so);
    }





}
